package com.tml.AIP_CRM_OPTY_QUERY2;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tml.AIP_CRM_OPTY_QUERY2.Dao.OptyAPIDao;

@SpringBootTest
class AipCrmOptyQueryApplicationTests {
	
	@Autowired
	private OptyAPIDao optyAPIDao;

	@Test
	void contextLoads() {
	}

}
