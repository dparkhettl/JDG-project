package com.tml.AIP_CRM_OPTY_QUERY2.Dao;
//import java.util.Map;

public interface OptyAPIDao {
	
	//public Map<String, Object> CheckDuplicateOpty(Map<String, String> map);
}
