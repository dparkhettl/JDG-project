package com.tml.AIP_CRM_OPTY_QUERY2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@SpringBootApplication(exclude = HibernateJpaAutoConfiguration.class)
public class AipCrmOptyQueryApplication {

	public static void main(String[] args) {
		//System.out.println("Hello world");
		SpringApplication.run(AipCrmOptyQueryApplication.class, args);
	}

}
