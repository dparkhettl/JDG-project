package com.taashee.datagrid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedhatDatagridApplicationTests {

	@Test
	void contextLoads() {
	}

}
