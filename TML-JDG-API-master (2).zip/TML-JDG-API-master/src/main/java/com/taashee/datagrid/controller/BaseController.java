package com.taashee.datagrid.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("cache")
public abstract class BaseController {}