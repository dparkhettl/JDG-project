package com.taashee.datagrid.controller;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.datagrid.service.OptyAPIDaoImpl;

@RestController
@RequestMapping(path = "/esb")

public class OptyQueryAPIController {
	private static final Logger LOGGER=LoggerFactory.getLogger(OptyQueryAPIController.class);

	@Autowired
	OptyAPIDaoImpl optyAPIDaoImpl;

	@PostMapping(path = "/CheckDuplicateOpty")
	public ResponseEntity<List<Map<String, String>>> CheckDuplicateOpty(@RequestBody Map<String,String> paramMap) {
		List<Map<String, String>> list  = null;
		try {
			//System.out.println("inside controller");
			list = optyAPIDaoImpl.CheckDuplicateOpty(paramMap);
			//list = optyAPIDaoImpl.CheckDuplicateOpty();
			
		} 
		catch (Exception e) {
			
			LOGGER.error(e.getMessage());
		}
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
}
