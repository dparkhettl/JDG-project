package com.taashee.datagrid.service;

public interface OptyAPIDao {
	//public Map<String, Object> CheckDuplicateOpty(Map<String, String> map);
}
