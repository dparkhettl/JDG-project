package com.taashee.datagrid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedhatDatagridApplication   {

	public static void main(String[] args) {
		SpringApplication.run(RedhatDatagridApplication.class, args);
	}

}
