package com.taashee.datagrid.service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.taashee.datagrid.service.OptyAPIDao;

@Repository
@Transactional
public class OptyAPIDaoImpl {
	//private static final Logger logger = LoggerFactory.getLogger(OptyAPIDaoImpl.class);


		@Autowired
		private SessionFactory sessionFactory;

		/*@Override
		public Map<String, Object> CheckDuplicateOpty(Map<String, String> map) {
			// TODO Auto-generated method stub
			return null;
		}*/
		
		public List<Map<String, String>> CheckDuplicateOpty(Map<String, String> paramMap) {
		//public List<Map<String, String>> CheckDuplicateOpty() {
			
			Session session = sessionFactory.getCurrentSession();
			String MOBILE_NO=paramMap.get("pMOBILE_NO");
			System.out.println("MOBILE_NO"+MOBILE_NO);
			String PPL=paramMap.get("pPPL");
			String DEALER_SALES_DIVISION=paramMap.get("pDEALER_SALES_DIVISION");
			
			String query="";
			HashMap<String, String> temp = new HashMap<String, String>();
			
				query = " SELECT DECODE(COUNT(1),0,'NO','YES') as DUPLICATE_OPTY "+
						" FROM S_STG STG,S_OPTY OPT,S_CONTACT C,S_POSTN POS,S_CONTACT POSCON,S_USER U,S_PROD_LN PL,S_PROD_LN PPL,S_ORG_EXT DIV  "+
						" WHERE  "+
						" STG.NAME IN ('02 Open Green Form','02a Pink Form','03 Open Yellow / Booked')  "+
						" AND OPT.CURR_STG_ID=STG.ROW_ID     "+
						" AND OPT.X_BU_UNIT='TMPC'  "+
						" AND C.ROW_ID=OPT.PR_CON_ID  "+
						" AND OPT.PR_POSTN_ID=POS.ROW_ID  "+
						" AND POSCON.ROW_ID=POS.PR_EMP_ID  "+
						" AND U.ROW_ID=POSCON.ROW_ID "+ 
						" AND U.STATUS_CD='Active'  "+
						" AND OPT.X_PROD_LN_ID=PL.ROW_ID  "+
						" AND PL.PAR_PROD_LN_ID=PPL.ROW_ID  "+
						" AND POS.OU_ID=DIV.ROW_ID  "+
						" AND (  "+
	" (OPT.ACTL_CLS_DT IS NOT NULL AND OPT.ACTL_CLS_DT > SYSDATE-90)   "+
	" OR (OPT.ACTL_CLS_DT IS NULL AND OPT.X_YF_OPEN_DT IS NOT NULL AND OPT.X_YF_OPEN_DT > SYSDATE-90)  "+  
	" OR (OPT.ACTL_CLS_DT IS NULL AND OPT.X_YF_OPEN_DT IS NULL AND OPT.X_C1A_DT IS NOT NULL AND OPT.X_C1A_DT > SYSDATE-90)    "+
	" OR (OPT.ACTL_CLS_DT IS NULL AND OPT.X_YF_OPEN_DT IS NULL AND OPT.X_C1A_DT IS NULL AND OPT.X_GF_OPEN_DT IS NOT NULL AND OPT.X_GF_OPEN_DT > SYSDATE-90)    "+
	" OR (OPT.ACTL_CLS_DT IS NULL AND OPT.X_YF_OPEN_DT IS NULL AND OPT.X_C1A_DT IS NULL AND OPT.X_GF_OPEN_DT IS NULL  AND OPT.X_STAGE1_DT IS NOT NULL AND OPT.X_STAGE1_DT > SYSDATE-90)    "+
	" )    "+
	" AND C.CELL_PH_NUM=:MOBILE_NO   "+
	" AND PPL.NAME=:PPL  "+
	" AND DIV.ROW_ID=:DEALER_SALES_DIVISION ";

			
			//query = " SELECT DECODE(COUNT(1),0,'NO','YES') from testdrive_temp where customer_type is not null ";

			NativeQuery<Object[]> queryObj = session.createNativeQuery(query);
			
				temp.put("details", "DUPLICATE_OPTY");
				queryObj.setParameter("MOBILE_NO", MOBILE_NO);
				queryObj.setParameter("PPL", PPL);
				queryObj.setParameter("DEALER_SALES_DIVISION", DEALER_SALES_DIVISION);
			
			List<Map<String, String>> Result = new ArrayList<Map<String, String>>();
			List<Object[]> rows = queryObj.getResultList();
			for (Object[] row : rows) {
				temp.put("DUPLICATE_OPTY", row[0].toString());
				
				Result.add((HashMap<String, String>) temp.clone());
			}

			return Result;
			
			
		}

}
